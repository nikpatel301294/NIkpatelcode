﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Controller : MonoBehaviour
{

    public float min_X, max_X;
    public float min_Y, max_Y;
    public GameObject otherobject;
    public float speed = 5f;
    public bool checkpos;
    public Vector2 moveX;
    public GameObject callani;
    public Vector3 startposition;

    [SerializeField]
    private GameObject player_Bullet;

    [SerializeField]
    private Transform attack_Point;

    public float attack_Timer = 0.1f;
    private float current_Attack_Timer;
    private bool canAttack;
    public static int manageani;
    public Vector3 endposition;

    private Vector3 screenPoint;
    private Vector3 offset;


    // Start is called before the first frame update
    void Start()
    {
        startposition = transform.position;

        endposition = new Vector3(-0.03f,- 3.32f,0f);

        current_Attack_Timer = attack_Timer;

        Invoke("Callplayer", 5.0f);

       
    }
    void Callplayer()
    {
      
        InvokeRepeating("spawnTrail", 1.0f, 0.15f);
        checkpos = true;
    }
    void OnMouseDown()
    {
        screenPoint = Camera.main.WorldToScreenPoint(gameObject.transform.position);

        offset = gameObject.transform.position - Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, screenPoint.z));

    }
    void OnMouseDrag()
    {
        Vector3 curScreenPoint = new Vector3(Input.mousePosition.x, Input.mousePosition.y, screenPoint.z);

        Vector3 curPosition = Camera.main.ScreenToWorldPoint(curScreenPoint);
        transform.position = curPosition;

    }
    // Update is called once per frame
    void Update()
    {
        if (checkpos == true)
        {
            gameObject.transform.localPosition = Vector3.MoveTowards(gameObject.transform.localPosition, otherobject.transform.localPosition, 5 * Time.deltaTime);

        }
        //if(gameObject.transform.localPosition == otherobject.transform.localPosition)
        //{
        //    checkpos = false;
        //}

        //moveX.y = Input.GetAxis("Vertical");

        //if(manageani==0)
        //{
        //    MovePlayer();
        //    Attack();
        //}




    }

   
    void MovePlayer()
    {

        //if (Input.GetAxisRaw("Vertical") > 0f)
        //{
        //    //   gameObject.transform.mo

        //    print("1");

        //    Vector3 temp = transform.position;
        //    temp.y = temp.y + speed * Time.deltaTime;

        //    if (temp.y > max_Y)
        //    {
        //        temp.y = max_Y;
        //    }

        //    transform.position = temp;
        //}

        //else if (Input.GetAxisRaw("Vertical") < 0f)
        //{
        //    Vector3 temp = transform.position;
        //    temp.y = temp.y - speed * Time.deltaTime;

        //    if (temp.y < min_Y)
        //    {
        //        temp.y = min_Y;
        //    }

        //    transform.position = temp;
        //}


        if (Input.GetAxisRaw("Horizontal") > 0f)
        {
            Vector3 temp = transform.position;
            temp.x = temp.x + speed * Time.deltaTime;

            if (temp.x > max_X)
            {
                temp.x = max_X;
            }

            transform.position = temp;
        }

        else if (Input.GetAxisRaw("Horizontal") < 0f)
        {
            Vector3 temp = transform.position;
            temp.x = temp.x - speed * Time.deltaTime;

            if (temp.x < min_X)
            {
                temp.x = min_X;
            }

            transform.position = temp;
        }

    }

    void Attack()
    {
        attack_Timer = attack_Timer + Time.deltaTime;

        if (attack_Timer > current_Attack_Timer)
        {
            canAttack = true;
        }

        
            if (canAttack)
            {
                canAttack = false;
                attack_Timer = 0f;

               /// Instantiate(player_Bullet, attack_Point.position, Quaternion.identity);
                
            }
        
    }

    void spawnTrail()
    {
        Debug.Log("bulle");

        if(manageani== 0)
        {
            Instantiate(player_Bullet, attack_Point.position, Quaternion.identity);
        }
        
        //laseraudio.Play();

       
    }

    void stopAnimation()
    {
        GetComponent<Animator>().enabled = false;
        Destroy(gameObject);
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        //if (other.CompareTag("EnemyBullateTag") && manageani==0)
        //{
        //    GameObject[] bullates = GameObject.FindGameObjectsWithTag("BullateTag");
        //    foreach (GameObject enemy in bullates)
        //        GameObject.Destroy(enemy);

        //    manageani = 1;
        //    gameObject.GetComponent<Animator>().enabled = true;
        //    Invoke("stopAnimation",2.0f);

            
        //}
        if ((other.CompareTag("EnemyTag1") || other.CompareTag("EnemyTag3") || other.CompareTag("EnemyBullate")) && manageani == 0)
        {
            GameObject[] bullates = GameObject.FindGameObjectsWithTag("BullateTag");
            foreach (GameObject enemy in bullates)
                GameObject.Destroy(enemy);

            Destroy(other.gameObject);
            manageani = 1;
            Debug.Log("objecttouch");
            gameObject.GetComponent<Animator>().enabled = true;
            gameObject.GetComponent<Animator>().transform.localScale= new Vector3(1f, 1f, 1f);
            Invoke("stopAnimation", 2.0f);
            SoundManagerScript.playsound("BombSound");
            

        }
    }

}
